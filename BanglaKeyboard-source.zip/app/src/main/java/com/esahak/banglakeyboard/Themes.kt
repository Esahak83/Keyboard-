package com.esahak.banglakeyboard

import android.content.Context

class KbTheme(
    val id: String,
    val name: String,
    val bg: Int,
    val key: Int,
    val keyText: Int,
    val hint: Int,
    val func: Int,
    val funcText: Int,
    val accent: Int,
    val accentText: Int,
    val space: Int,
    val border: Int,
    val icon: Int
)

object Themes {
    private fun c(v: Long): Int = v.toInt()

    val all: List<KbTheme> = listOf(
        KbTheme("dark_red", "ডার্ক রেড",
            c(0xFF0A0F14), c(0xFF161C24), c(0xFFFFFFFF), c(0xFF9AA5B1),
            c(0xFF161C24), c(0xFFE53935), c(0xFFD50000), c(0xFFFFFFFF),
            c(0xFF2A2724), c(0xFF1E4D4A), c(0xFFE53935)),
        KbTheme("green", "বাংলার সবুজ",
            c(0xFF0B4D3A), c(0xFFF1F5F2), c(0xFF12241B), c(0xFF4F6257),
            c(0xFFC9DCCF), c(0xFF12241B), c(0xFFF42A41), c(0xFFFFFFFF),
            c(0xFFF1F5F2), c(0x22000000), c(0xFFE6F2EA)),
        KbTheme("amoled", "অ্যামোলেড",
            c(0xFF000000), c(0xFF121212), c(0xFFEDEDED), c(0xFF7C7C7C),
            c(0xFF1E1E1E), c(0xFFFFFFFF), c(0xFF00C853), c(0xFF000000),
            c(0xFF1E1E1E), c(0xFF2A2A2A), c(0xFF00C853)),
        KbTheme("ocean", "সাগর",
            c(0xFF123A5C), c(0xFFEAF2F9), c(0xFF0F2236), c(0xFF4A5E72),
            c(0xFFBCD3E6), c(0xFF0F2236), c(0xFFFF6B4A), c(0xFF2A0A02),
            c(0xFFEAF2F9), c(0x22000000), c(0xFFD7E8F5)),
        KbTheme("sunset", "সূর্যাস্ত",
            c(0xFF2B1B3D), c(0xFF3E2A55), c(0xFFFFE8D6), c(0xFFC9A9C9),
            c(0xFF55386F), c(0xFFFFD2A8), c(0xFFFF7A3D), c(0xFF2B0F00),
            c(0xFF4A3463), c(0xFF5E4378), c(0xFFFFB27A)),
        KbTheme("rose", "গোলাপি",
            c(0xFFFFE3EC), c(0xFFFFFFFF), c(0xFF4A1230), c(0xFFB06A8A),
            c(0xFFF7BDD1), c(0xFF4A1230), c(0xFFE91E63), c(0xFFFFFFFF),
            c(0xFFFFFFFF), c(0x33C2185B), c(0xFFC2185B)),
        KbTheme("mint", "পুদিনা",
            c(0xFFD8F3E8), c(0xFFFFFFFF), c(0xFF0E3B2C), c(0xFF5B8A78),
            c(0xFFB3E4CE), c(0xFF0E3B2C), c(0xFF00A676), c(0xFFFFFFFF),
            c(0xFFFFFFFF), c(0x330E3B2C), c(0xFF00765A)),
        KbTheme("light", "ক্লাসিক সাদা",
            c(0xFFE9ECEF), c(0xFFFFFFFF), c(0xFF1F2933), c(0xFF7B8794),
            c(0xFFCBD2D9), c(0xFF1F2933), c(0xFF1976D2), c(0xFFFFFFFF),
            c(0xFFFFFFFF), c(0x1A000000), c(0xFF52606D)),
        KbTheme("purple", "বেগুনি স্বপ্ন",
            c(0xFF1A1033), c(0xFF2A1B52), c(0xFFEFE7FF), c(0xFFA899D6),
            c(0xFF3A2670), c(0xFFD9C8FF), c(0xFF9C5CFF), c(0xFFFFFFFF),
            c(0xFF33225F), c(0xFF4B3592), c(0xFFB794FF)),
        KbTheme("gold", "রাজকীয় সোনালি",
            c(0xFF14110A), c(0xFF241E10), c(0xFFF6E7B4), c(0xFFA9966A),
            c(0xFF33290F), c(0xFFFFD25A), c(0xFFFFC107), c(0xFF1F1500),
            c(0xFF2E2612), c(0xFF4A3C14), c(0xFFFFC107)),
        KbTheme("cyber", "সাইবার নিয়ন",
            c(0xFF05070F), c(0xFF0D1224), c(0xFF00F0FF), c(0xFF7A5CFF),
            c(0xFF121A33), c(0xFFFF2BD6), c(0xFFFF2BD6), c(0xFF05070F),
            c(0xFF10172D), c(0xFF1B3A6B), c(0xFF00F0FF)),
        KbTheme("coffee", "কফি",
            c(0xFF3B2A20), c(0xFFF3E5D8), c(0xFF3B2A20), c(0xFF8B6B55),
            c(0xFFD2B79F), c(0xFF3B2A20), c(0xFF8D5524), c(0xFFFFFFFF),
            c(0xFFF3E5D8), c(0x33000000), c(0xFFF3E5D8)),
        KbTheme("lavender", "ল্যাভেন্ডার",
            c(0xFFE8E1F5), c(0xFFFFFFFF), c(0xFF2E1F4D), c(0xFF8C7BB0),
            c(0xFFD0C4EA), c(0xFF2E1F4D), c(0xFF7E57C2), c(0xFFFFFFFF),
            c(0xFFFFFFFF), c(0x332E1F4D), c(0xFF5E35B1)),
        KbTheme("forest", "গভীর বন",
            c(0xFF0F1F17), c(0xFF1B3126), c(0xFFDDF5E6), c(0xFF7FAE95),
            c(0xFF254333), c(0xFFA8F0C6), c(0xFF2ECC71), c(0xFF03150B),
            c(0xFF22402F), c(0xFF2F5A43), c(0xFF2ECC71)),
        KbTheme("ice", "বরফ নীল",
            c(0xFF0D1B2A), c(0xFF1B2B40), c(0xFFE0F2FF), c(0xFF7FA3C4),
            c(0xFF243A55), c(0xFF8FD3FF), c(0xFF29B6F6), c(0xFF001B2A),
            c(0xFF203149), c(0xFF2E4A6B), c(0xFF4FC3F7)),
        KbTheme("fire", "আগুন",
            c(0xFF1A0A06), c(0xFF2B140C), c(0xFFFFE3D0), c(0xFFC98A6A),
            c(0xFF3D1C10), c(0xFFFF9A5C), c(0xFFFF3D00), c(0xFFFFFFFF),
            c(0xFF351A0F), c(0xFF5A2A18), c(0xFFFF7043))
    )

    fun byId(id: String?): KbTheme = all.firstOrNull { it.id == id } ?: all[0]

    fun current(ctx: Context): KbTheme = byId(Store.getTheme(ctx))
}
