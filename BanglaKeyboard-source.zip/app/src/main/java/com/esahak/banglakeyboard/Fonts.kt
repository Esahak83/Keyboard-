package com.esahak.banglakeyboard

import android.content.Context
import android.graphics.Typeface

/**
 * Stylish key fonts. The .ttf files are downloaded into assets/fonts while the app is built
 * (see app/build.gradle.kts). A font whose file is missing is simply not offered.
 */
object Fonts {
    class F(val id: String, val name: String, val file: String?)

    val all: List<F> = listOf(
        F("default", "সাধারণ", null),
        F("galada", "গালাদা", "Galada-Regular.ttf"),
        F("atma", "আত্মা", "Atma-Bold.ttf"),
        F("mina", "মিনা", "Mina-Bold.ttf"),
        F("tiro", "তিরো", "TiroBangla-Regular.ttf"),
        F("hind", "হিন্দ", "HindSiliguri-Bold.ttf")
    )

    private val cache = HashMap<String, Typeface?>()

    fun load(ctx: Context, id: String?): Typeface? {
        val f = all.firstOrNull { it.id == id } ?: return null
        val file = f.file ?: return null
        if (cache.containsKey(file)) return cache[file]
        val tf = try {
            Typeface.createFromAsset(ctx.assets, "fonts/$file")
        } catch (e: Exception) {
            null
        }
        cache[file] = tf
        return tf
    }

    fun available(ctx: Context): List<F> = all.filter { it.file == null || load(ctx, it.id) != null }
}
