# বাংলা কিবোর্ড (Android)

রিদমিক ধাঁচের বাংলা + ইংরেজি কিবোর্ড অ্যাপ।

- বাংলা (বিজয় ধাঁচ) ও ইংরেজি, ডান দিকে টান দিয়ে বা স্পেসবারে টান দিয়ে ভাষা বদল
- উপরের টুলবার: ইমোজি, কপি, পেস্ট, সেভ, সংরক্ষিত/ক্লিপবোর্ড তালিকা, সব সিলেক্ট, থিম
- ১৬টি থিম
- কি-তে ধরে রাখলে ছোট করে লেখা সংখ্যা/চিহ্ন বসে

## GitHub-এ APK বানানো

1. GitHub-এ নতুন repo খুলুন।
2. `BanglaKeyboard-source.zip` ফাইলটা repo-তে আপলোড করুন (Add file -> Upload files)।
3. Add file -> Create new file -> নাম দিন `.github/workflows/build.yml` -> `build.yml` এর লেখা পেস্ট করে Commit করুন।
4. Actions ট্যাবে "Build APK" চলবে। শেষ হলে নিচে Artifacts থেকে `BanglaKeyboard-APK` নামিয়ে জিপ খুলে `app-debug.apk` ইনস্টল করুন।
5. অ্যাপ খুলে ধাপ ১ ও ২ করুন।
