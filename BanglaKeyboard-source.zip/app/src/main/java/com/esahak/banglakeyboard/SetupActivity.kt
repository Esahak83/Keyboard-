package com.esahak.banglakeyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SetupActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var themeBox: LinearLayout

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, bold: Boolean, color: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(Color.parseColor(color))
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        t.layoutParams = lp
        return t
    }

    private fun stepButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 16f
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        lp.topMargin = dp(10)
        b.layoutParams = lp
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#F3F6F4"))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(32), dp(20), dp(32))
        sv.addView(col)

        col.addView(label("বাংলা কিবোর্ড", 30f, true, "#0B4D3A"))
        col.addView(label("বাংলা ও ইংরেজি, ইমোজি, কপি-সেভ আর অনেক থিম একসাথে।", 15f, false, "#44524A"))

        status = label("", 15f, true, "#1B1B1B")
        status.setPadding(dp(14), dp(12), dp(14), dp(12))
        status.setBackgroundColor(Color.parseColor("#E1EBE5"))
        col.addView(status)

        col.addView(stepButton("১. কিবোর্ড চালু করুন") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(label("খোলা পাতায় \"বাংলা কিবোর্ড\" অন করুন।", 13f, false, "#6A786F"))

        col.addView(stepButton("২. এই কিবোর্ড বেছে নিন") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        col.addView(label("৩. এখানে টাইপ করে দেখুন", 16f, true, "#0B4D3A"))
        val test = EditText(this)
        test.hint = "এখানে লিখুন (ডান দিকে টান দিলে ভাষা বদলাবে)"
        test.minLines = 3
        test.gravity = android.view.Gravity.TOP
        col.addView(test, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        col.addView(label("থিম বেছে নিন", 18f, true, "#0B4D3A"))
        themeBox = LinearLayout(this)
        themeBox.orientation = LinearLayout.VERTICAL
        col.addView(themeBox)
        buildThemes()

        setContentView(sv)
    }

    private fun buildThemes() {
        themeBox.removeAllViews()
        val current = Themes.current(this).id
        val all = Themes.all
        var i = 0
        while (i < all.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (j in 0 until 3) {
                if (i + j < all.size) {
                    val t = all[i + j]
                    val v = ThemePreview(this, t, t.id == current)
                    v.setOnClickListener {
                        Store.setTheme(this, t.id)
                        buildThemes()
                    }
                    val lp = LinearLayout.LayoutParams(0, dp(86), 1f)
                    lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                    row.addView(v, lp)
                } else {
                    row.addView(View(this), LinearLayout.LayoutParams(0, dp(86), 1f))
                }
            }
            themeBox.addView(row)
            i += 3
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val selected = cur.startsWith("$packageName/")
        status.text = when {
            selected -> "✓ কিবোর্ড চালু আছে এবং এখন এটাই ব্যবহার হচ্ছে।"
            enabled -> "কিবোর্ড চালু আছে। এবার ধাপ ২ থেকে এটা বেছে নিন।"
            else -> "কিবোর্ড এখনো চালু করা হয়নি। ধাপ ১ দিয়ে শুরু করুন।"
        }
    }
}
