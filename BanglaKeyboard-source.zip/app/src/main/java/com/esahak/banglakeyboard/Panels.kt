package com.esahak.banglakeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private fun dpi(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

/** Emoji picker: category tabs on top, grid below. */
class EmojiPanel(
    ctx: Context,
    private val theme: KbTheme,
    private val onPick: (String) -> Unit
) : LinearLayout(ctx) {

    private val cats = listOf(
        "😀" to Emojis.smileys,
        "❤️" to Emojis.hearts,
        "🐶" to Emojis.nature,
        "🍔" to Emojis.food,
        "⚽" to Emojis.objects,
        "🔣" to Emojis.symbols
    )
    private var items: List<String> = cats[0].second
    private val tabs = ArrayList<TextView>()
    private val grid = GridView(ctx)

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val c = parent!!.context
            val t = (convertView as? TextView) ?: TextView(c).apply {
                textSize = 24f
                gravity = Gravity.CENTER
                layoutParams = AbsListView.LayoutParams(MATCH, dpi(c, 44))
            }
            t.text = items[position]
            return t
        }
    }

    init {
        orientation = VERTICAL
        val bar = LinearLayout(ctx)
        bar.orientation = HORIZONTAL
        cats.forEachIndexed { i, cat ->
            val t = TextView(ctx)
            t.text = cat.first
            t.textSize = 20f
            t.gravity = Gravity.CENTER
            t.setOnClickListener { select(i) }
            tabs.add(t)
            bar.addView(t, LayoutParams(0, MATCH, 1f))
        }
        addView(bar, LayoutParams(MATCH, dpi(ctx, 40)))

        grid.numColumns = 8
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.selector = ColorDrawable(Color.TRANSPARENT)
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> onPick(items[pos]) }
        addView(grid, LayoutParams(MATCH, 0, 1f))
        select(0)
    }

    private fun select(i: Int) {
        items = cats[i].second
        adapter.notifyDataSetChanged()
        grid.setSelection(0)
        tabs.forEachIndexed { j, t ->
            t.background = if (j == i) rounded(theme.key, dpi(context, 10)) else null
        }
    }
}

private fun rounded(color: Int, radius: Int): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radius.toFloat()
    return g
}

/** Saved texts and clipboard history. */
class SavedPanel(
    ctx: Context,
    private val theme: KbTheme,
    private val onPick: (String) -> Unit
) : LinearLayout(ctx) {

    private var key = "saved"
    private var items: MutableList<String> = ArrayList()
    private val list = ListView(ctx)
    private val empty = TextView(ctx)
    private val tabSaved = TextView(ctx)
    private val tabClip = TextView(ctx)

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val c = parent!!.context
            val t = (convertView as? TextView) ?: TextView(c).apply {
                textSize = 16f
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dpi(c, 14), dpi(c, 11), dpi(c, 14), dpi(c, 11))
                background = rounded(theme.key, dpi(c, 10))
                setTextColor(theme.keyText)
            }
            t.text = items[position]
            return t
        }
    }

    init {
        orientation = VERTICAL

        val bar = LinearLayout(ctx)
        bar.orientation = HORIZONTAL
        for ((tv, label) in listOf(tabSaved to "সংরক্ষিত", tabClip to "ক্লিপবোর্ড")) {
            tv.text = label
            tv.textSize = 15f
            tv.gravity = Gravity.CENTER
            tv.setTypeface(tv.typeface, android.graphics.Typeface.BOLD)
            bar.addView(tv, LayoutParams(0, MATCH, 1f))
        }
        tabSaved.setOnClickListener { key = "saved"; refresh() }
        tabClip.setOnClickListener { key = "clips"; refresh() }
        addView(bar, LayoutParams(MATCH, dpi(ctx, 40)))

        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = dpi(ctx, 6)
        list.setPadding(dpi(ctx, 8), dpi(ctx, 4), dpi(ctx, 8), dpi(ctx, 4))
        list.clipToPadding = false
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> if (pos in items.indices) onPick(items[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            Store.removeAt(context, key, pos)
            Toast.makeText(context, "মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
            refresh()
            true
        }

        empty.gravity = Gravity.CENTER
        empty.textSize = 14f
        empty.setTextColor(theme.hint)
        empty.setPadding(dpi(ctx, 24), 0, dpi(ctx, 24), 0)

        val body = FrameLayout(ctx)
        body.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))
        body.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(body, LayoutParams(MATCH, 0, 1f))
        refresh()
    }

    private fun refresh() {
        items = Store.list(context, key)
        adapter.notifyDataSetChanged()
        val isEmpty = items.isEmpty()
        empty.visibility = if (isEmpty) View.VISIBLE else View.GONE
        empty.text = if (key == "saved") {
            "এখনো কিছু সংরক্ষণ করা হয়নি।\nলেখা লিখে উপরের বুকমার্ক বাটনে চাপুন।\n(ট্যাপ করলে লেখা বসবে, ধরে রাখলে মুছবে)"
        } else {
            "কপি করা লেখা এখানে জমা হবে।"
        }
        val on = key == "saved"
        tabSaved.setTextColor(if (on) theme.accent else theme.icon)
        tabClip.setTextColor(if (!on) theme.accent else theme.icon)
        tabSaved.background = if (on) rounded(theme.key, dpi(context, 10)) else null
        tabClip.background = if (!on) rounded(theme.key, dpi(context, 10)) else null
    }
}

/** Small preview card of a theme, used in the in-keyboard picker and in the setup screen. */
class ThemePreview(ctx: Context, val th: KbTheme, var selected: Boolean) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = 3 * d
        r.set(m, m, w - m, h - m)
        p.style = Paint.Style.FILL
        p.color = th.bg
        c.drawRoundRect(r, 12 * d, 12 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = (if (selected) 2.5f else 1f) * d
        p.color = if (selected) th.accent else Color.argb(70, 128, 128, 128)
        c.drawRoundRect(r, 12 * d, 12 * d, p)

        val left = r.left + 10 * d
        val right = r.right - 10 * d
        val top = r.top + 9 * d
        val nameH = 20 * d
        val bottom = r.bottom - nameH
        val gap = 3 * d
        val rowH = (bottom - top - 2 * gap) / 3f
        val counts = intArrayOf(6, 5, 4)
        p.style = Paint.Style.FILL
        for (row in 0 until 3) {
            val n = counts[row]
            val kw = (right - left - (n - 1) * gap) / n
            for (i in 0 until n) {
                val kl = left + i * (kw + gap)
                val kt = top + row * (rowH + gap)
                p.color = if (row == 2 && i == n - 1) th.accent else if (row == 2 && i == 0) th.func else th.key
                r.set(kl, kt, kl + kw, kt + rowH)
                c.drawRoundRect(r, 3 * d, 3 * d, p)
            }
        }
        p.color = th.icon
        p.textAlign = Paint.Align.CENTER
        p.textSize = 12 * d
        c.drawText(if (selected) "✓ " + th.name else th.name, w / 2f, h - 9 * d, p)
    }
}

/** Grid of themes. Tapping one saves it and calls [onChosen]. */
class ThemePanel(
    ctx: Context,
    private val currentId: String,
    private val onChosen: (KbTheme) -> Unit
) : LinearLayout(ctx) {

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = Themes.all.size
        override fun getItem(position: Int): Any = Themes.all[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val t = Themes.all[position]
            val v = ThemePreview(parent!!.context, t, t.id == currentId)
            v.layoutParams = AbsListView.LayoutParams(MATCH, dpi(parent.context, 82))
            return v
        }
    }

    init {
        orientation = VERTICAL
        val grid = GridView(ctx)
        grid.numColumns = 3
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.selector = ColorDrawable(Color.TRANSPARENT)
        grid.setPadding(dpi(ctx, 6), dpi(ctx, 4), dpi(ctx, 6), dpi(ctx, 4))
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ ->
            val t = Themes.all[pos]
            Store.setTheme(context, t.id)
            onChosen(t)
        }
        addView(grid, LayoutParams(MATCH, MATCH))
    }
}
