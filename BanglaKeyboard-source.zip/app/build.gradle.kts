plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.esahak.banglakeyboard"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.esahak.banglakeyboard"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

// Download stylish Bengali fonts (OFL licensed, from Google Fonts) into assets while building.
// If a download fails the font is skipped and the app still builds.
val downloadFonts = tasks.register("downloadFonts") {
    doLast {
        val fontDir = File(projectDir, "src/main/assets/fonts")
        fontDir.mkdirs()
        val base = "https://raw.githubusercontent.com/google/fonts/main/ofl"
        val files = mapOf(
            "Galada-Regular.ttf" to "galada/Galada-Regular.ttf",
            "Atma-Bold.ttf" to "atma/Atma-Bold.ttf",
            "Mina-Bold.ttf" to "mina/Mina-Bold.ttf",
            "TiroBangla-Regular.ttf" to "tirobangla/TiroBangla-Regular.ttf",
            "HindSiliguri-Bold.ttf" to "hindsiliguri/HindSiliguri-Bold.ttf"
        )
        for ((name, path) in files) {
            val out = File(fontDir, name)
            if (out.exists() && out.length() > 1000L) continue
            try {
                java.net.URL("$base/$path").openStream().use { input ->
                    out.outputStream().use { o -> input.copyTo(o) }
                }
                println("font downloaded: $name")
            } catch (e: Exception) {
                println("font skipped: $name ($e)")
                out.delete()
            }
        }
    }
}

tasks.matching { it.name == "preBuild" || (it.name.startsWith("merge") && it.name.endsWith("Assets")) }
    .configureEach { dependsOn(downloadFonts) }
