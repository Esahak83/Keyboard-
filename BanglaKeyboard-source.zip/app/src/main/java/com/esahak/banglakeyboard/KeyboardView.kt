package com.esahak.banglakeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View

/**
 * The key area. Draws everything itself (no XML), handles multi-touch typing,
 * long-press hints, backspace repeat and the swipe that switches Bangla <-> English.
 */
class KeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(s: String)
        fun onBackspace()
        fun onEnter()
        fun onLang(lang: Int)
        fun onTyped()
    }

    var listener: Listener? = null

    /** 0 = Bangla, 1 = English */
    var lang = 0
        private set

    /** 0 = off, 1 = next letter, 2 = caps lock */
    var shift = 0
        private set

    /** 0 = letters, 1 = symbols, 2 = more symbols */
    var page = 0
        private set

    private var theme: KbTheme = Themes.all[0]
    private var rows: List<Row> = Layouts.letters(0)
    private val uiHandler = Handler(Looper.getMainLooper())

    private val density = context.resources.displayMetrics.density
    private fun dp(v: Float): Float = v * density
    private fun sp(v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
    }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val hintP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.RIGHT }
    private val rect = RectF()
    private val path = Path()
    private val icons = HashMap<Int, Drawable>()

    private class Ptr(val key: Key, val x0: Float, val y0: Float) {
        var longDone = false
        var swiped = false
        var lp: Runnable? = null
        var rep: Runnable? = null
    }

    private val ptrs = HashMap<Int, Ptr>()
    private var lastShift = 0L

    private val dependent = "ৃুূিীাৈেোৌ্ঁ"

    // ---------------------------------------------------------------- public API

    fun setKbTypeface(tf: android.graphics.Typeface?) {
        textP.typeface = tf ?: android.graphics.Typeface.DEFAULT
        invalidate()
    }

    fun setKbTheme(t: KbTheme) {
        theme = t
        invalidate()
    }

    fun setLanguage(l: Int, withAnim: Boolean) {
        lang = l
        shift = 0
        rebuild()
        if (withAnim) {
            animate().cancel()
            translationX = width * 0.22f
            alpha = 0.3f
            animate().translationX(0f).alpha(1f).setDuration(180).start()
        }
    }

    fun toggleLang() {
        setLanguage(1 - lang, true)
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        listener?.onLang(lang)
    }

    fun showPage(p: Int) {
        page = p
        rebuild()
    }

    fun setShiftState(s: Int) {
        if (shift != s) {
            shift = s
            invalidate()
        }
    }

    // ---------------------------------------------------------------- layout

    private fun rebuild() {
        rows = if (page == 0) Layouts.letters(lang) else Layouts.symbols(lang, page)
        layoutKeys()
        invalidate()
    }

    private var heightDp = 324

    fun setKbHeight(h: Int) {
        if (h != heightDp) {
            heightDp = h
            requestLayout()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), dp(heightDp.toFloat()).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys()
    }

    private fun layoutKeys() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val padX = dp(3f)
        val padY = dp(4f)
        val totalH = h - 2 * padY
        var sumH = 0f
        for (r in rows) sumH += r.h
        var y = padY
        for (row in rows) {
            val rh = totalH * row.h / sumH
            var sumW = 0f
            for (k in row.keys) sumW += k.w
            val avail = w - 2 * padX
            var x = padX
            for (k in row.keys) {
                val kw = avail * k.w / sumW
                k.l = x
                k.r = x + kw
                k.t = y
                k.b = y + rh
                x += kw
            }
            y += rh
        }
    }

    // ---------------------------------------------------------------- drawing

    private fun disp(s: String): String =
        if (s.isNotEmpty() && dependent.indexOf(s[0]) >= 0) "◌$s" else s

    private fun glyph(k: Key): String =
        if (page == 0 && shift > 0 && k.s.isNotEmpty()) k.s else k.n

    /** English keys always show capital letters (like Ridmik); the typed letter still follows shift. */
    private fun shown(k: Key): String =
        if (lang == 1 && page == 0 && k.s.isNotEmpty()) k.s else glyph(k)

    private fun tweak(col: Int): Int {
        val lum = 0.299 * Color.red(col) + 0.587 * Color.green(col) + 0.114 * Color.blue(col)
        val t = if (lum < 140) 255 else 0
        val a = 0.18f
        return Color.rgb(
            (Color.red(col) + (t - Color.red(col)) * a).toInt(),
            (Color.green(col) + (t - Color.green(col)) * a).toInt(),
            (Color.blue(col) + (t - Color.blue(col)) * a).toInt()
        )
    }

    private fun drawCentered(c: Canvas, s: String, cx: Float, cy: Float, p: Paint) {
        val fm = p.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, p)
    }

    private fun drawIcon(c: Canvas, res: Int, cx: Float, cy: Float, size: Float, color: Int) {
        val dr = icons.getOrPut(res) { context.getDrawable(res)!!.mutate() }
        dr.setTint(color)
        val h = (size / 2f).toInt()
        dr.setBounds(cx.toInt() - h, cy.toInt() - h, cx.toInt() + h, cy.toInt() + h)
        dr.draw(c)
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(theme.bg)
        val gap = dp(2.5f)
        val rad = dp(9f)
        for (row in rows) {
            for (k in row.keys) {
                if (k.type == KType.SPACER) continue
                val p = ptrs.values.firstOrNull { it.key === k }
                val shiftOn = k.type == KType.SHIFT && shift > 0
                var fill = when (k.type) {
                    KType.CHAR -> theme.key
                    KType.SPACE -> theme.space
                    KType.ENTER -> theme.accent
                    else -> if (shiftOn) theme.accent else theme.func
                }
                if (p != null) fill = tweak(fill)
                rect.set(k.l + gap, k.t + gap, k.r - gap, k.b - gap)
                fillP.color = fill
                c.drawRoundRect(rect, rad, rad, fillP)
                if (p == null && Color.alpha(theme.border) > 0) {
                    strokeP.color = theme.border
                    c.drawRoundRect(rect, rad, rad, strokeP)
                }
                val cx = (rect.left + rect.right) / 2f
                val cy = (rect.top + rect.bottom) / 2f
                when (k.type) {
                    KType.CHAR -> {
                        val big = p != null && p.longDone && k.hint.isNotEmpty()
                        val s = if (big) k.hint else disp(shown(k))
                        textP.color = if (big) theme.accent else theme.keyText
                        val rowDp = (k.b - k.t) / density
                        val base = (rowDp * 0.38f).coerceIn(20f, 28f)
                        textP.textSize = sp(if (s.length > 2) base * 0.82f else base)
                        drawCentered(c, s, cx, cy, textP)
                        if (!big && k.hint.isNotEmpty()) {
                            hintP.color = theme.hint
                            hintP.textSize = sp(if (rowDp > 60f) 13f else 11f)
                            c.drawText(k.hint, rect.right - dp(6f), rect.top + dp(15f), hintP)
                        }
                    }
                    KType.SPACE -> {
                        textP.color = theme.keyText
                        textP.textSize = sp(16f)
                        drawCentered(c, if (lang == 0) "বাংলা" else "English", cx, cy, textP)
                        textP.color = theme.hint
                        textP.textSize = sp(14f)
                        drawCentered(c, "◂", rect.left + dp(22f), cy, textP)
                        drawCentered(c, "▸", rect.right - dp(22f), cy, textP)
                    }
                    KType.SHIFT -> {
                        drawIcon(c, R.drawable.ic_shift, cx, cy, dp(24f), if (shiftOn) theme.accentText else theme.funcText)
                        if (shift == 2) {
                            fillP.color = theme.accentText
                            c.drawRoundRect(cx - dp(8f), rect.bottom - dp(8f), cx + dp(8f), rect.bottom - dp(5f), dp(1.5f), dp(1.5f), fillP)
                        }
                    }
                    KType.BACKSPACE -> drawIcon(c, R.drawable.ic_backspace, cx, cy, dp(26f), theme.funcText)
                    KType.ENTER -> drawIcon(c, R.drawable.ic_enter, cx, cy, dp(26f), theme.accentText)
                    KType.LANG -> {
                        textP.color = theme.funcText
                        textP.textSize = sp(15f)
                        drawCentered(c, if (lang == 0) "বাং" else "EN", cx, cy, textP)
                    }
                    else -> {
                        textP.color = theme.funcText
                        textP.textSize = sp(15f)
                        drawCentered(c, k.label, cx, cy, textP)
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- touch

    private fun keyAt(x: Float, y: Float): Key? {
        if (rows.isEmpty()) return null
        val row = rows.firstOrNull { r -> r.keys.isNotEmpty() && y >= r.keys[0].t && y < r.keys[0].b }
            ?: (if (y < rows.first().keys[0].t) rows.first() else rows.last())
        val keys = row.keys
        var idx = keys.indexOfFirst { x >= it.l && x < it.r }
        if (idx < 0) idx = if (x < keys.first().l) 0 else keys.size - 1
        var k = keys[idx]
        if (k.type == KType.SPACER) k = if (idx == 0) keys[1] else keys[idx - 1]
        return k
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                up(e.getPointerId(e.actionIndex))
            }
            MotionEvent.ACTION_CANCEL -> cancelAll()
        }
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        val k = keyAt(x, y) ?: return
        val p = Ptr(k, x, y)
        ptrs[id] = p
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (k.type == KType.BACKSPACE) {
            listener?.onBackspace()
            val rep = object : Runnable {
                override fun run() {
                    listener?.onBackspace()
                    uiHandler.postDelayed(this, 55)
                }
            }
            val start = Runnable {
                p.longDone = true
                uiHandler.post(rep)
            }
            p.rep = rep
            p.lp = start
            uiHandler.postDelayed(start, 380)
        } else if (k.type == KType.CHAR && k.hint.isNotEmpty()) {
            val start = Runnable {
                p.longDone = true
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                invalidate()
            }
            p.lp = start
            uiHandler.postDelayed(start, 380)
        }
        invalidate()
    }

    private fun move(id: Int, x: Float) {
        val p = ptrs[id] ?: return
        if (p.swiped) return
        val k = p.key
        val spaceSwipe = k.type == KType.SPACE &&
            Math.abs(x - p.x0) > maxOf(dp(70f), (k.r - k.l) * 0.3f)
        val edgeSwipe = p.x0 > width * 0.88f && (p.x0 - x) > width * 0.3f
        if (spaceSwipe || edgeSwipe) {
            p.swiped = true
            release(p)
            toggleLang()
        }
    }

    private fun release(p: Ptr) {
        p.lp?.let { uiHandler.removeCallbacks(it) }
        p.rep?.let { uiHandler.removeCallbacks(it) }
    }

    private fun cancelAll() {
        for (p in ptrs.values) release(p)
        ptrs.clear()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        cancelAll()
        super.onDetachedFromWindow()
    }

    private fun up(id: Int) {
        val p = ptrs.remove(id) ?: return
        release(p)
        invalidate()
        if (p.swiped) return
        val k = p.key
        when (k.type) {
            KType.CHAR -> {
                val text = if (p.longDone && k.hint.isNotEmpty()) k.hint else glyph(k)
                listener?.onText(text)
                if (shift == 1) shift = 0
                invalidate()
                listener?.onTyped()
            }
            KType.SPACE -> {
                listener?.onText(" ")
                listener?.onTyped()
            }
            KType.ENTER -> listener?.onEnter()
            KType.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                shift = when (shift) {
                    0 -> 1
                    1 -> if (now - lastShift < 400) 2 else 0
                    else -> 0
                }
                lastShift = now
                invalidate()
            }
            KType.SYMBOLS -> showPage(1)
            KType.LETTERS -> showPage(0)
            KType.SYMPAGE -> showPage(if (page == 1) 2 else 1)
            KType.LANG -> toggleLang()
            else -> {
            }
        }
    }
}
