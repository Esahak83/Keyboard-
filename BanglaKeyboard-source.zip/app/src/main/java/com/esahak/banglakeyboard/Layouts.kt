package com.esahak.banglakeyboard

enum class KType { CHAR, SHIFT, BACKSPACE, ENTER, SPACE, SYMBOLS, LETTERS, SYMPAGE, LANG, SPACER }

/**
 * n     = normal output / label
 * s     = output when shift is on (empty = same as n)
 * hint  = small character at the top-right corner, typed on long press
 * w     = width weight inside the row
 */
class Key(
    val type: KType,
    val n: String = "",
    val s: String = "",
    val hint: String = "",
    val w: Float = 1f,
    val label: String = ""
) {
    var l = 0f
    var t = 0f
    var r = 0f
    var b = 0f
}

class Row(val keys: List<Key>, val h: Float = 1f)

object Layouts {
    private const val EN_DIGITS = "1234567890"
    private const val BN_DIGITS = "১২৩৪৫৬৭৮৯০"

    // Bijoy style fixed layout: letter -> (normal, shift)
    private val BN: Map<Char, Pair<String, String>> = mapOf(
        'q' to ("ঙ" to "ং"), 'w' to ("য" to "য়"), 'e' to ("ড" to "ঢ"), 'r' to ("প" to "ফ"),
        't' to ("ট" to "ঠ"), 'y' to ("চ" to "ছ"), 'u' to ("জ" to "ঝ"), 'i' to ("হ" to "ঞ"),
        'o' to ("গ" to "ঘ"), 'p' to ("ড়" to "ঢ়"),
        'a' to ("ৃ" to "র্"), 's' to ("ু" to "ূ"), 'd' to ("ি" to "ী"), 'f' to ("া" to "অ"),
        'g' to ("্" to "।"), 'h' to ("ব" to "ভ"), 'j' to ("ক" to "খ"), 'k' to ("ত" to "থ"),
        'l' to ("দ" to "ধ"),
        'z' to ("্র" to "ঁ"), 'x' to ("ও" to "ঔ"), 'c' to ("ে" to "ৈ"), 'v' to ("র" to "ল"),
        'b' to ("ন" to "ণ"), 'n' to ("স" to "ষ"), 'm' to ("ম" to "শ")
    )

    private val STRIP = listOf("আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ো", "ৌ", "ঃ", "ৎ")

    private fun letter(ch: Char, bn: Boolean, hint: String): Key {
        if (bn) {
            val p = BN.getValue(ch)
            return Key(KType.CHAR, n = p.first, s = p.second, hint = hint)
        }
        return Key(KType.CHAR, n = ch.toString(), s = ch.uppercaseChar().toString(), hint = hint)
    }

    fun letters(lang: Int): List<Row> {
        val bn = lang == 0
        val rows = ArrayList<Row>()

        if (bn) {
            rows.add(Row(STRIP.map { Key(KType.CHAR, n = it) }, 0.8f))
        }

        val digits = if (bn) BN_DIGITS else EN_DIGITS
        val r1 = ArrayList<Key>()
        "qwertyuiop".forEachIndexed { i, ch -> r1.add(letter(ch, bn, digits[i].toString())) }
        rows.add(Row(r1))

        val h2 = listOf("@", "#", if (bn) "৳" else "\$", "%", "&", "-", "+", "(", ")")
        val r2 = ArrayList<Key>()
        r2.add(Key(KType.SPACER, w = 0.5f))
        "asdfghjkl".forEachIndexed { i, ch -> r2.add(letter(ch, bn, h2[i])) }
        r2.add(Key(KType.SPACER, w = 0.5f))
        rows.add(Row(r2))

        val h3 = listOf("*", "\"", "'", ":", ";", "!", "?")
        val r3 = ArrayList<Key>()
        r3.add(Key(KType.SHIFT, w = 1.5f))
        "zxcvbnm".forEachIndexed { i, ch -> r3.add(letter(ch, bn, h3[i])) }
        r3.add(Key(KType.BACKSPACE, w = 1.5f))
        rows.add(Row(r3))

        val r4 = ArrayList<Key>()
        r4.add(Key(KType.SYMBOLS, w = 1.4f, label = "?123"))
        r4.add(Key(KType.CHAR, n = ",", w = 1f))
        r4.add(Key(KType.LANG, w = 1.2f))
        r4.add(Key(KType.SPACE, w = 4.1f))
        if (bn) {
            r4.add(Key(KType.CHAR, n = "।", hint = ".", w = 1f))
        } else {
            r4.add(Key(KType.CHAR, n = ".", w = 1f))
        }
        r4.add(Key(KType.ENTER, w = 1.5f))
        rows.add(Row(r4))
        return rows
    }

    private fun chars(s: String): List<Key> = s.map { Key(KType.CHAR, n = it.toString()) }

    fun symbols(lang: Int, page: Int): List<Row> {
        val bn = lang == 0
        val rows = ArrayList<Row>()

        if (page == 1) {
            rows.add(Row(chars(if (bn) BN_DIGITS else EN_DIGITS)))
            rows.add(Row(chars(if (bn) "@#৳_&-+()/" else "@#\$_&-+()/")))
            val r3 = ArrayList<Key>()
            r3.add(Key(KType.SYMPAGE, w = 1.5f, label = "=\\<"))
            r3.addAll(chars("*\"':;!?"))
            r3.add(Key(KType.BACKSPACE, w = 1.5f))
            rows.add(Row(r3))
        } else {
            rows.add(Row(chars("~`|•√π÷×¶∆")))
            rows.add(Row(chars("£¢€¥^°={}\\")))
            val r3 = ArrayList<Key>()
            r3.add(Key(KType.SYMPAGE, w = 1.5f, label = "?123"))
            r3.addAll(chars("%©®™✓[]"))
            r3.add(Key(KType.BACKSPACE, w = 1.5f))
            rows.add(Row(r3))
        }

        val r4 = ArrayList<Key>()
        r4.add(Key(KType.LETTERS, w = 1.4f, label = if (bn) "কখগ" else "ABC"))
        r4.add(Key(KType.CHAR, n = ",", w = 1f))
        r4.add(Key(KType.SPACE, w = 5.3f))
        r4.add(Key(KType.CHAR, n = if (bn) "।" else ".", w = 1f))
        r4.add(Key(KType.ENTER, w = 1.5f))
        rows.add(Row(r4))
        return rows
    }
}
