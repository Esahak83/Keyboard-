package com.esahak.banglakeyboard

import android.content.Context
import org.json.JSONArray

/** Small helper around SharedPreferences: language, theme, saved texts, clipboard history. */
object Store {
    private const val PREFS = "kb_prefs"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getLang(ctx: Context): Int = sp(ctx).getInt("lang", 0)

    fun setLang(ctx: Context, lang: Int) {
        sp(ctx).edit().putInt("lang", lang).apply()
    }

    /** Height of the key area in dp. */
    fun getHeight(ctx: Context): Int = sp(ctx).getInt("height", 324)

    fun setHeight(ctx: Context, h: Int) {
        sp(ctx).edit().putInt("height", h).apply()
    }

    fun getFont(ctx: Context): String = sp(ctx).getString("font", "default") ?: "default"

    fun setFont(ctx: Context, id: String) {
        sp(ctx).edit().putString("font", id).apply()
    }

    fun getTheme(ctx: Context): String? = sp(ctx).getString("theme", null)

    fun setTheme(ctx: Context, id: String) {
        sp(ctx).edit().putString("theme", id).apply()
    }

    fun list(ctx: Context, key: String): MutableList<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(sp(ctx).getString(key, "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
            // ignore broken data
        }
        return out
    }

    private fun write(ctx: Context, key: String, items: List<String>) {
        val a = JSONArray()
        for (s in items) a.put(s)
        sp(ctx).edit().putString(key, a.toString()).apply()
    }

    fun add(ctx: Context, key: String, text: String, max: Int) {
        val items = list(ctx, key)
        items.remove(text)
        items.add(0, text)
        while (items.size > max) items.removeAt(items.size - 1)
        write(ctx, key, items)
    }

    fun removeAt(ctx: Context, key: String, index: Int) {
        val items = list(ctx, key)
        if (index in items.indices) {
            items.removeAt(index)
            write(ctx, key, items)
        }
    }
}
