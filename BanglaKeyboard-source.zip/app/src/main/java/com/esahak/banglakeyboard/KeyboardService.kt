package com.esahak.banglakeyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class BanglaKeyboardService : InputMethodService(), KeyboardView.Listener {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var root: LinearLayout
    private lateinit var toolbar: LinearLayout
    private lateinit var frame: FrameLayout
    private lateinit var kv: KeyboardView

    private var theme: KbTheme = Themes.all[0]
    private var panelHost: LinearLayout? = null
    private var currentPanel: String? = null
    private val toolButtons = ArrayList<ImageView>()
    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        registerClip()
    }

    override fun onDestroy() {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipListener?.let { cm.removePrimaryClipChangedListener(it) }
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        theme = Themes.current(this)
        toolButtons.clear()
        panelHost = null
        currentPanel = null

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        toolbar = LinearLayout(this)
        toolbar.orientation = LinearLayout.HORIZONTAL
        toolbar.gravity = Gravity.CENTER_VERTICAL
        addTool(R.drawable.ic_emoji, "ইমোজি") { togglePanel("emoji") }
        addTool(R.drawable.ic_copy, "কপি") { doCopy() }
        addTool(R.drawable.ic_paste, "পেস্ট") { doPaste() }
        addTool(R.drawable.ic_save, "সেভ") { doSave() }
        addTool(R.drawable.ic_list, "সংরক্ষিত ও ক্লিপবোর্ড") { togglePanel("saved") }
        addTool(R.drawable.ic_select_all, "সব সিলেক্ট") { currentInputConnection?.performContextMenuAction(android.R.id.selectAll) }
        addTool(R.drawable.ic_palette, "থিম") { togglePanel("theme") }
        root.addView(toolbar, LinearLayout.LayoutParams(MATCH, dp(48)))

        frame = FrameLayout(this)
        kv = KeyboardView(this)
        kv.listener = this
        kv.setKbHeight(Store.getHeight(this))
        kv.setKbTypeface(Fonts.load(this, Store.getFont(this)))
        kv.setLanguage(Store.getLang(this), false)
        frame.addView(kv, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(frame, LinearLayout.LayoutParams(MATCH, WRAP))

        applyTheme()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::root.isInitialized) return
        theme = Themes.current(this)
        applyTheme()
        hidePanel()
        kv.setKbHeight(Store.getHeight(this))
        kv.setKbTypeface(Fonts.load(this, Store.getFont(this)))
        kv.showPage(0)
        updateAutoShift()
    }

    // ---------------------------------------------------------------- KeyboardView.Listener

    override fun onText(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            val before = ic.getTextBeforeCursor(2, 0)
            if (before.isNullOrEmpty()) {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            } else {
                val n = if (before.length == 2 &&
                    Character.isHighSurrogate(before[0]) &&
                    Character.isLowSurrogate(before[1])
                ) 2 else 1
                ic.deleteSurroundingText(n, 0)
            }
        }
        updateAutoShift()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val opts = ei?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnter = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnter && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateAutoShift()
    }

    override fun onLang(lang: Int) {
        Store.setLang(this, lang)
        updateAutoShift()
    }

    override fun onTyped() {
        updateAutoShift()
    }

    private fun updateAutoShift() {
        if (!::kv.isInitialized) return
        if (kv.lang != 1 || kv.shift == 2 || kv.page != 0) return
        val ei = currentInputEditorInfo
        val ic = currentInputConnection
        var caps = 0
        if (ei != null && ic != null && ei.inputType != InputType.TYPE_NULL) {
            caps = ic.getCursorCapsMode(ei.inputType)
        }
        kv.setShiftState(if (caps != 0) 1 else 0)
    }

    // ---------------------------------------------------------------- toolbar actions

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun fieldText(): String {
        val ic = currentInputConnection ?: return ""
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) return sel.toString()
        val before = ic.getTextBeforeCursor(20000, 0) ?: ""
        val after = ic.getTextAfterCursor(20000, 0) ?: ""
        return before.toString() + after.toString()
    }

    private fun doCopy() {
        val t = fieldText()
        if (t.isEmpty()) {
            toast("কপি করার মতো লেখা নেই")
            return
        }
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("text", t))
            toast("কপি হয়েছে")
        } catch (e: Exception) {
            toast("কপি করা গেল না")
        }
    }

    private fun doPaste() {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this)?.toString() else null
            if (t.isNullOrEmpty()) toast("ক্লিপবোর্ড খালি") else onText(t)
        } catch (e: Exception) {
            toast("পেস্ট করা গেল না")
        }
    }

    private fun doSave() {
        val t = fieldText().trim()
        if (t.isEmpty()) {
            toast("সেভ করার মতো লেখা নেই")
            return
        }
        Store.add(this, "saved", t, 100)
        toast("সংরক্ষিত হয়েছে")
    }

    // ---------------------------------------------------------------- panels

    private fun togglePanel(kind: String) {
        if (currentPanel == kind) hidePanel() else showPanel(kind)
    }

    private fun showPanel(kind: String) {
        hidePanel()
        val body: View = when (kind) {
            "emoji" -> EmojiPanel(this, theme) { onText(it) }
            "saved" -> SavedPanel(this, theme) { onText(it) }
            else -> ThemePanel(this, theme.id, Store.getFont(this), { t ->
                theme = t
                applyTheme()
                showPanel("theme")
            }, { id ->
                Store.setFont(this, id)
                kv.setKbTypeface(Fonts.load(this, id))
                showPanel("theme")
            })
        }
        val host = LinearLayout(this)
        host.orientation = LinearLayout.VERTICAL
        host.setBackgroundColor(theme.bg)
        host.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
        host.addView(bottomBar(), LinearLayout.LayoutParams(MATCH, dp(48)))
        frame.addView(host, FrameLayout.LayoutParams(MATCH, MATCH))
        kv.visibility = View.INVISIBLE
        panelHost = host
        currentPanel = kind
    }

    private fun hidePanel() {
        panelHost?.let { frame.removeView(it) }
        panelHost = null
        currentPanel = null
        if (::kv.isInitialized) kv.visibility = View.VISIBLE
    }

    private fun bottomBar(): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(4), dp(4), dp(4), dp(4))

        val back = TextView(this)
        back.text = if (kv.lang == 0) "কখগ" else "ABC"
        back.gravity = Gravity.CENTER
        back.textSize = 15f
        back.setTypeface(back.typeface, Typeface.BOLD)
        back.setTextColor(theme.funcText)
        back.background = round(theme.func, dp(10))
        back.setOnClickListener { hidePanel() }
        bar.addView(back, LinearLayout.LayoutParams(0, MATCH, 1.4f).also { it.setMargins(dp(2), 0, dp(2), 0) })

        bar.addView(View(this), LinearLayout.LayoutParams(0, MATCH, 5f))

        val del = ImageView(this)
        del.setImageResource(R.drawable.ic_backspace)
        del.setColorFilter(theme.funcText)
        del.setPadding(dp(10), dp(8), dp(10), dp(8))
        del.background = round(theme.func, dp(10))
        del.setOnClickListener { onBackspace() }
        bar.addView(del, LinearLayout.LayoutParams(0, MATCH, 1.4f).also { it.setMargins(dp(2), 0, dp(2), 0) })
        return bar
    }

    // ---------------------------------------------------------------- theme

    private fun applyTheme() {
        if (!::root.isInitialized) return
        root.setBackgroundColor(theme.bg)
        kv.setKbTheme(theme)
        for (iv in toolButtons) {
            iv.setColorFilter(theme.icon)
            iv.background = pressBg(theme.key)
        }
    }

    private fun round(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radius.toFloat()
        return g
    }

    private fun pressBg(color: Int): Drawable {
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_pressed), round(color, dp(10)))
        sl.addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
        return sl
    }

    private fun addTool(res: Int, desc: String, action: () -> Unit) {
        val iv = ImageView(this)
        iv.setImageResource(res)
        iv.contentDescription = desc
        iv.setPadding(dp(6), dp(6), dp(6), dp(6))
        iv.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(0, MATCH, 1f)
        lp.setMargins(dp(3), dp(4), dp(3), dp(4))
        toolbar.addView(iv, lp)
        toolButtons.add(iv)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- clipboard history

    private fun registerClip() {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val l = ClipboardManager.OnPrimaryClipChangedListener {
                try {
                    val c = cm.primaryClip
                    if (c != null && c.itemCount > 0) {
                        val t = c.getItemAt(0).coerceToText(this)?.toString()
                        if (!t.isNullOrBlank()) Store.add(this, "clips", t, 30)
                    }
                } catch (e: Exception) {
                }
            }
            cm.addPrimaryClipChangedListener(l)
            clipListener = l
        } catch (e: Exception) {
        }
    }
}
